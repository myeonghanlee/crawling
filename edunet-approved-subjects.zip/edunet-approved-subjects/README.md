# 에듀넷 교육감 승인과목 수집기

에듀넷의 교육감 승인 과목 중 **2022 개정 교육과정** 자료를 읽어 다음 항목을 CSV로 내보내는 Streamlit 앱입니다.

- 과목명
- 관련교과(교과군)
- 학교급
- 소속(기관)
- 교과서명
- 상태
- 작성일

## 데이터 수집 방식

에듀넷 화면이 사용하는 읽기 전용 API를 사용합니다. 목록은 `CRCLM01`(2022 교육과정)으로 필터링합니다. 과목별 상세 본문에 `1. 교과(군):` 항목이 있으면 그 값을 결과의 **관련교과(교과군)** 열에 넣고, 항목이 없거나 상세 본문이 비어 있으면 기존 상세/목록의 관련교과 값을 보조값으로 사용합니다. 교과서명도 상세 응답에서 가져오므로 각 과목의 상세 API를 추가 조회합니다.

현재 확인 시 목록은 **5,384건**이었으며 사이트 화면의 15건 기준 **359페이지**였습니다. API가 한 번에 100건까지 반환하는 것도 확인되어 앱 기본값을 100건으로 설정했습니다(기본값에서 목록 호출은 약 54회, 상세 호출은 최대 5,384회). 사이트 데이터는 계속 바뀔 수 있습니다.

최근 목록 상위 15건의 상세 본문은 비어 있었으므로, `교과(군)` 값이 실제로 존재하는지 먼저 일부 페이지로 시험해 보세요. 현재 확인한 API는 로그인 쿠키 없이도 읽기 요청에 응답했습니다. 따라서 이 앱은 에듀넷 비밀번호, 로그인 쿠키, GitHub 토큰을 입력받거나 저장하지 않습니다. API 접근 방식 또는 에듀넷 정책이 바뀌면 수집을 중단하고 허용된 인증·이용 방식부터 확인하세요.

## 로컬에서 실행

Python 3.11 이상을 권장합니다.

```bash
python -m venv .venv
# macOS/Linux
source .venv/bin/activate
# Windows PowerShell은 .venv\\Scripts\\Activate.ps1
pip install -r requirements.txt
streamlit run app.py
```

앱에서 먼저 1페이지 정도를 수집해 CSV와 라벨이 맞는지 확인한 뒤 전체 범위를 실행하세요. 페이지당 목록 수는 15/50/100으로 선택할 수 있습니다. 요청 시작 간격 기본값은 0.5초이며, 응답 오류나 429가 발생하면 간격을 늘리고 전체 수집을 다시 실행하기 전에 사이트 상태를 확인하세요.

교과서명을 포함한 전체 5천여 건을 한 번에 수집하면 상세 요청이 5천 회 이상 발생하고, 여러십 분이 걸릴 수 있습니다. 페이지 범위를 나누어 다운로드하는 방법도 있습니다. 실패한 상세 조회 행은 목록 필드만 남고 교과서명은 빈칸이며, 앱에서 실패 ID를 보여 줍니다.

## GitHub에 저장하고 Streamlit Community Cloud에 배포

1. GitHub에서 저장소를 만듭니다. 개인정보가 포함된 결과 파일을 올리지 않도록 처음에는 **Private** 저장소를 권장합니다.
2. `app.py`, `edunet_crawler.py`, `requirements.txt`, `README.md`, `.gitignore`를 저장소 루트에 올립니다. `data/` 안의 CSV/JSONL 파일, `.streamlit/secrets.toml`, `.env`는 커밋하지 마세요.
3. Streamlit Community Cloud에서 해당 저장소와 브랜치를 선택하고 앱 파일을 `app.py`로 지정해 배포합니다.
4. API가 실제 배포 환경에서도 정상 응답하는지 1페이지 시험 수집을 먼저 실행하세요. 로그인 상태를 앱이 대신 유지하는 설계가 아니므로 계정 비밀번호나 브라우저 쿠키를 Streamlit secrets에 추가하지 마세요.

GitHub에 업로드할 때 예시:

```bash
git init
git add app.py edunet_crawler.py requirements.txt README.md .gitignore tests
# 저장소 URL을 추가한 후
git remote add origin <사용자 저장소 URL>
git branch -M main
git commit -m "Add Edunet 2022 subject crawler"
git push -u origin main
```

## 프로젝트 구조

```text
.
├── app.py                  # Streamlit 화면, 설정, 진행률 및 CSV 다운로드
├── edunet_crawler.py       # API 호출, 코드 라벨 변환, 요청 간격·재시도
├── requirements.txt
├── tests/
│   └── test_edunet_crawler.py
└── data/                   # 로컬 수집 파일을 둘 수 있으나 Git에서는 제외
```

## 이용 시 주의

- 이 프로젝트는 목록 및 상세를 **읽기만** 하며 게시물 작성·수정·삭제, 파일 다운로드를 하지 않습니다.
- 요청 간격과 동시 상세 조회 수를 기본적으로 보수적으로 설정했습니다. 서버 오류가 나면 동시성을 높이지 말고 요청 간격을 늘리세요.
- 수집 결과를 공개·재배포하기 전에 에듀넷 이용약관, 저작권 및 데이터 이용 조건을 확인하세요.
