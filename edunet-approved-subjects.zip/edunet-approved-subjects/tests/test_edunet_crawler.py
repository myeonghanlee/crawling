import unittest
from unittest.mock import patch

from edunet_crawler import crawl_2022_subjects, _date_only, _extract_course_group


class CrawlerTests(unittest.TestCase):
    def test_date_only(self):
        self.assertEqual(_date_only("2026-11-06T17:19:47"), "2026-11-06")
        self.assertEqual(_date_only(None), "")

    def test_extracts_course_group_from_html_or_plain_text(self):
        html_body = (
            "<p>1. 교과(군): <strong>보통교과(국어)</strong></p>"
            "<p>2. 승인허용 학교 유형: 일반고</p><p>3. 권장이수학점: 2</p>"
        )
        plain_body = "1. 교과(군):\n전문교과(전기전자)\n2. 승인허용 학교 유형: 특성화고"

        self.assertEqual(_extract_course_group(html_body), "보통교과(국어)")
        self.assertEqual(_extract_course_group(plain_body), "전문교과(전기전자)")
        self.assertEqual(_extract_course_group("본문에 교과(군) 항목이 없음"), "")

    @patch("edunet_crawler.fetch_code_maps")
    @patch("edunet_crawler._detail")
    @patch("edunet_crawler._list_page")
    def test_maps_detail_fields_and_respects_page_selection(self, list_page, detail, codes):
        list_page.return_value = {
            "pagingProperty": {"countItem": 1, "countPage": 1},
            "dataList": [
                {
                    "pstId": 123,
                    "pstTtl": "과목 A",
                    "relSbj": "관련교과군",
                    "pstSchlLvlCd": "SLV03",
                    "pstSchlTypeCd": "LOC10",
                    "aprvYnCd": "APRV01",
                    "regDt": "2026-11-06T12:00:00",
                }
            ],
        }
        detail.return_value = {
            "pstId": 123,
            "pstTtl": "과목 A",
            "relSbj": "목록의 기존 관련교과 값",
            "pstCn": "<p>1. 교과(군): 보통교과(국어)</p><p>2. 승인허용 학교 유형: 일반고</p>",
            "pstSchlLvlCd": "SLV03",
            "pstSchlTypeCd": "LOC10",
            "pstTxbNm": "교과서 X",
            "aprvYnCd": "APRV01",
            "regDt": "2026-11-06T00:00:00",
        }
        codes.return_value = {
            "SLV_CD": {"SLV03": "고등학교"},
            "LOC_CD": {"LOC10": "충청북도교육청"},
            "APRV_CD": {"APRV01": "승인완료"},
        }

        result = crawl_2022_subjects(page_size=100, interval_seconds=0)

        self.assertEqual(result.total_items, 1)
        self.assertEqual(result.total_site_pages, 1)
        self.assertEqual(result.rows, [{
            "과목명": "과목 A",
            "관련교과(교과군)": "보통교과(국어)",
            "학교급": "고등학교",
            "소속(기관)": "충청북도교육청",
            "교과서명": "교과서 X",
            "상태": "승인완료",
            "작성일": "2026-11-06",
        }])
        detail.assert_called_once_with(123, unittest.mock.ANY)


if __name__ == "__main__":
    unittest.main()
